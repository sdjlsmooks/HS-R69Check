﻿Public Class FormObject

    Public CurrentRow As RowObject

    Public FormId As String

    Public MultipleIteration As Boolean

    Public OtherRows() As RowObject

End Class
