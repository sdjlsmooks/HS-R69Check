﻿Public Class RowObject

    Public Fields() As FieldObject

    Public ParentRowId As String

    Public RowAction As String

    Public RowId As String

End Class
